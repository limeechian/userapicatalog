

export interface Coordinate {
     latitude: number;
     longitude: number;
     


}